﻿namespace Market.Models;

public sealed record Product(Guid Id, string Name, string Description, decimal Price, DateTime CreatedAt, DateTime UpdatedAt);
