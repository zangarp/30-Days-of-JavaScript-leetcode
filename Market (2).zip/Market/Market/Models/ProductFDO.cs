﻿namespace Market.Models;
public sealed record ProductFDO(string Name, string Description, decimal Price);

