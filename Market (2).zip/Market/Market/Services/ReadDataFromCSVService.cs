﻿using CsvHelper;
using Market.Models;
using System.Globalization;

namespace Market.Services;

public sealed class ReadDataFromCSVService
{
    public static List<ProductFDO> ReadData(string path)
    {
        using var reader = new StreamReader(path);
        using var csv = new CsvReader(reader, CultureInfo.InvariantCulture);
        var data = csv.GetRecords<ProductFDO>().ToList();
        return data;
    }
}
