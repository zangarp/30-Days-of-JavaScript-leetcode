using Market.Models;
using Market.Services;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Market.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ProductController : ControllerBase
    {
        private readonly ILogger<ProductController> _logger;
        private readonly AppDbContext _dbContext;
        private readonly ReadDataFromCSVService _readDataFromCSVService;

        public ProductController(ILogger<ProductController> logger, AppDbContext dbContext, ReadDataFromCSVService readDataFromCSVService)
        {
            _logger = logger;
            _dbContext = dbContext;
            _readDataFromCSVService = readDataFromCSVService;
        }

        [HttpPost]
        public async Task<Results<Ok, BadRequest<string>, StatusCodeHttpResult>> CreateNewProduct([FromBody] ProductFDO request)
        {
            try
            {
                if(string.IsNullOrWhiteSpace(request.Name) || string.IsNullOrWhiteSpace(request.Description) || request.Price <= 0)
                {
                    return TypedResults.BadRequest("Invalid request data");
                }

                var product = new Product(Guid.NewGuid(), request.Name, request.Description, request.Price, DateTime.Now, DateTime.Now);
                await _dbContext.Products.AddAsync(product);
                await _dbContext.SaveChangesAsync();
                _logger.LogInformation("New product created: {ProductId}", product.Id);
                return TypedResults.Ok();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to create new product");
                return TypedResults.StatusCode(500);
            }
        }

        [HttpPut]
        public async Task<Results<Ok, BadRequest<string>, StatusCodeHttpResult>> UpdateProductById(Guid productId, [FromBody] ProductFDO request)
        {
            try
            {
                var product =  await _dbContext.Products.AsNoTracking().FirstOrDefaultAsync(s => s.Id == productId);
                if(product is null)
                {
                    return TypedResults.BadRequest("Product not found");
                }

                if(string.IsNullOrWhiteSpace(request.Name) || string.IsNullOrWhiteSpace(request.Description) || request.Price <= 0)
                {
                    return TypedResults.BadRequest("Invalid request data");
                }

                product = product with
                {
                    Name = request.Name,
                    Description = request.Description,
                    Price = request.Price,
                    UpdatedAt = DateTime.Now
                };

                _dbContext.Entry(product).State = EntityState.Modified;
                await _dbContext.SaveChangesAsync();
                _logger.LogInformation("Product updated: {ProductId}", product.Id);
                return TypedResults.Ok();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to update product");
                return TypedResults.StatusCode(500);
            }
        }

        [HttpDelete]
        public async Task<Results<Ok, BadRequest<string>, StatusCodeHttpResult>> DeleteProductById(Guid productId)
        {
            try
            {
                var product = await _dbContext.Products.FindAsync(productId);
                if(product is null)
                {
                    return TypedResults.BadRequest("Product not found");
                }

                _dbContext.Products.Remove(product);
                await _dbContext.SaveChangesAsync();
                _logger.LogInformation("Product deleted: {ProductId}", product.Id);
                return TypedResults.Ok();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to delete product");
                return TypedResults.StatusCode(500);
            }
        }

        [HttpGet]
        public async Task<Results<Ok<List<Product>>, StatusCodeHttpResult>> GetAllProductsWithPagination(int page, int pageSize)
        {
            try
            {
                var products = await _dbContext.Products.Skip(page * pageSize).Take(pageSize).ToListAsync();
                return TypedResults.Ok(products);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to get all products");
                return TypedResults.StatusCode(500);
            }
        }

        [HttpPost("fill-from-csv")]
        public async Task<Results<Ok, BadRequest<string>, StatusCodeHttpResult>> WriteFromCSVTODBProducts()
        {
            try
            {
                var products = ReadDataFromCSVService.ReadData("C:\\Users\\yerge\\OneDrive\\������� ����\\products.csv").Distinct();
                foreach (var product in products)
                {
                    await _dbContext.Products.AddAsync(new Product(Guid.NewGuid(), product.Name, product.Description, product.Price, DateTime.Now, DateTime.Now));
                }
                await _dbContext.SaveChangesAsync();
                return TypedResults.Ok();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to write products from CSV to DB");
                return TypedResults.StatusCode(500);
            }
        }
    }
}
